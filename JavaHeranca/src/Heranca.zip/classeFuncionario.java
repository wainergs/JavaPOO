
public class classeFuncionario {
	private String nome, matricula;
	protected double salarioBase;
	
	public classeFuncionario(String nome, String matricula, double salarioBase) {
		super();
		this.nome = nome;
		this.matricula = matricula;
		this.salarioBase = salarioBase;
	}
	
	
	
	public String getNome() {
		return nome;
	}



	private void setNome(String nome) {
		this.nome = nome;
	}



	public String getMatricula() {
		return matricula;
	}



	private void setMatricula(String matricula) {
		this.matricula = matricula;
	}



	public double getSalarioBase() {
		return salarioBase;
	}



	private void setSalarioBase(double salarioBase) {
		this.salarioBase = salarioBase;
	}



	double calculaSalario(){
		return salarioBase;
	}
	

}

class Gerente extends classeFuncionario{


	public Gerente(String nome, String matricula, double salarioBase) {
		super(nome, matricula, salarioBase);
		// TODO Auto-generated constructor stub
	}

	double calculaSalario(){
		return salarioBase*2;
	}
}

class Assistente extends classeFuncionario{
	public Assistente(String nome, String matricula, double salarioBase) {
		super(nome, matricula, salarioBase);
		// TODO Auto-generated constructor stub
	}

	double calculaSalario(){
		return salarioBase;
	}
}
class Vendedor extends classeFuncionario{
	private double comissao;

	public Vendedor(String nome, String matricula, double salarioBase,double vendas) {
		super(nome, matricula, salarioBase);
		this.comissao = vendas;
	}
	double calculaSalario(){
		return salarioBase + comissao;
	}
	
}