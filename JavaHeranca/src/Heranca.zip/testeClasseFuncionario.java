
public class testeClasseFuncionario {

	public static void main(String[] args) {

		Assistente a1 = new Assistente("Eduardo", "2019001", 998.00);
		
		System.out.println("Nome: "+a1.getNome()+"\n"+
		"Matricula: "+a1.getMatricula()+"\n"+
		"Salario Base: "+a1.calculaSalario());
	
		System.out.println();
	
	Gerente g1 = new Gerente("Joao", "2019--1", 2000);
	System.out.println("Nome: "+g1.getNome()+"\n"+
			"Matricula: "+g1.getMatricula()+"\n"+
			"Salario Base: "+g1.calculaSalario());
	
	System.out.println();
	
	Vendedor v1 = new Vendedor("Maria", "V2019-9003", 998.00, 500.00);
	System.out.println("Nome: "+v1.getNome()+"\n"+
			"Matricula: "+v1.getMatricula()+"\n"+
			"Salario Base: "+v1.calculaSalario());
}
}