
public class testeExercicio1 {

	public static void main(String[] args) {
		C teste = new C();
		
		System.out.println(teste);
	}

}

//A classe C só "pega" o local da referencia das variaveis da Classe A
//Ela não é capaz de pegar os valores dessas variaveis
